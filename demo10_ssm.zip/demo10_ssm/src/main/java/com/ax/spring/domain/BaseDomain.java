package com.ax.spring.domain;

public class BaseDomain {

}
