package com.ax.spring.dao;

public interface IGenericDAO {
}
